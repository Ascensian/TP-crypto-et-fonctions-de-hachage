const encryptButton = document.getElementById('encryptButton');
const decryptButton = document.getElementById('decryptButton');
const textInput = document.getElementById('textInput');
const keyInput = document.getElementById('keyInput');
const algorithmSelect = document.getElementById('algorithmSelect');
const resultTextArea = document.getElementById('resultTextArea');

encryptButton.addEventListener('click', () => {
  const algorithm = algorithmSelect.value;
  const text = textInput.value;
  const key = CryptoJS.enc.Utf8.parse(keyInput.value);

  switch (algorithm) {
    case 'md5':
      resultTextArea.value = CryptoJS.MD5(text).toString();
      break;
    case 'sha256':
      resultTextArea.value = CryptoJS.SHA256(text).toString();
      break;
    case 'keccak512':
      resultTextArea.value = CryptoJS.SHA3(text, { outputLength: 512 }).toString();
      break;
  }
});

